import os

os.system("sshpass -p EI21! ssh EI@192.168.50.1 reboot")
