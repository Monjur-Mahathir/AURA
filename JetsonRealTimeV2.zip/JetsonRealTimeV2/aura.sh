#!/bin/sh

while true
do
    killall -9 python3
    sleep 2
    konsole -e "python3 run_model.py" & 
    sleep 40
    count=10
    while [ $count -gt 0 ]
    do
        konsole -e "python3 realtime.py"
        sleep 1
        count=$(( $count - 1 ))
    done
done
